Quran Light Institute — OLD CODE archive
=========================================
Source: GitHub wordbitx/quran_inst, main branch
Last commit archived: e0744d45 (Round 8: mobile top bar number + WhatsApp icon, 10 Nov 2026)
Archived: 11 Nov 2026
This is the complete old design (Next.js 14 + TypeScript + Tailwind) before the
Minha-style rebuild. To restore: unzip, run `npm install`, then `npm run build`
and `npm run dev`. node_modules and .next build output are NOT in this zip
(reinstallable from package-lock.json).
Contents: full source (src/), public images/logo/icons, configs, package.json,
package-lock.json, README.md, testimonial-request-drafts.md, .env.example.
Official number in this code: +92 305 6622104. No prices invented.
